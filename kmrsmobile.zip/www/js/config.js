var krms_config ={
	'ApiUrl':"http://daakme.com/restomulti/mobileapp/api",
	'DialogDefaultTitle':"FoodBangladesh Food Delivery",
	'pushNotificationSenderid':"116916930979",
	'facebookAppId':"547842305666224",
	'APIHasKey':"a293d85619be06d9476430ff3e641ac4"
};